const router = require("express").Router();
const cPeserta = require("../controllers/peserta.js");

router.get("/restu-ganteng", cPeserta.ambilSemuaData);

module.exports = router;