let config = {
  user: "root",
  password: "",
  database: "boba",
  host: "localhost",
  multipleStatements: true,
}

module.exports = config;