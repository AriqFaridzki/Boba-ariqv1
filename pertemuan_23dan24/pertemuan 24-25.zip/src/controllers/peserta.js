const database = require("../config/database.js");
const mysql = require("mysql");
const pool = mysql.createPool(database);

pool.on("error", (err) => {
  console.log(err);
});

let listData = {
  ambilSemuaData(req, res){
    pool.getConnection((err, connection) => {
      if (err) {
        console.log("ERROR NIH")
      }

      let query = "SELECT * FROM peserta";
      connection.query(query, (error, response) => {
        res.send({ data: response });
      });
      connection.release();

    })
  }
}

module.exports = listData;