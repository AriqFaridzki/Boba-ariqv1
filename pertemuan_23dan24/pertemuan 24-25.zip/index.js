const bodyParser = require("body-parser");
const express = require("express");
const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const router = require("./src/routes/peserta-route.js");
app.use("/", router);

app.listen(8080, () => {
  console.log("SERVER SUDAH BERHASIL DIJALANKAN")
})